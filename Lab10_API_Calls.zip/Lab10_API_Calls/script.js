//TASK 1//
document.getElementById('DataButton').addEventListener('click', function() {
    fetch('https://jsonplaceholder.typicode.com/posts/1')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            console.log(data);
            displayData(data);
        })
        .catch(error => console.error('Error fetching data:', error));
});

function displayData(data) {
    const fetchedSection = document.getElementById('fetchedSection');

    fetchedSection.innerHTML = ''; // Clear previous data

//Fetching the title and body as requested
    const titleId = document.createElement('h1');
    titleId.textcontent = 'Title: ' + data.title;

    const bodyId = document.createElement('p');
    bodyId.textContent = 'Body: ' + data.body;

    fetchedSection.appendChild(titleId);
    fetchedSection.appendChild(bodyId);

    };

//TASK 2 XHR//
document.getElementById('XHRButton').addEventListener('click', function() {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', 'https://jsonplaceholder.typicode.com/posts/2', true);

    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) { 
            if (xhr.status === 200) { // 200 means the request was successful
                const data = JSON.parse(xhr.responseText);
                console.log(data);
                displayData(data);
            } else {
                console.error('Error fetching data:', xhr.statusText);
            }
        }
    };

    xhr.send();
});

function displayData(data) {
    const tableBody = document.getElementById('XHRButton');
    tableBody.innerHTML = ''; // Clear previous data 
};

//TASK 3: POST//
document.getElementById('postName').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent default form submission

    // Get form data
    const title = document.getElementById('title').value;
    const body = document.getElementById('body').value;

    // Create a new post object
    const postData = {
        title: title,
        body: body,
        userId: 1  
    };

    // Send POST request using fetch
    fetch('https://jsonplaceholder.typicode.com/posts', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(postData)  
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();  // Parse the response as JSON
    })
    .then(data => {
        // confirmation message with response data
        const confirmationMessage = document.getElementById('confirmationMessage');
        confirmationMessage.innerHTML = `<p>Post created successfully!</p>
                                         <p><strong>Title:</strong> ${data.title}</p>
                                         <p><strong>Body:</strong> ${data.body}</p>
                                         <p><strong>Post ID:</strong> ${data.id}</p>`;
    })
    .catch(error => {
        // error message if the request fails
        const confirmationMessage = document.getElementById('confirmationMessage');
        confirmationMessage.innerHTML = `<p style="color: red;">Error: ${error.message}</p>`;
    }); 
});

//TASK 4//
document.getElementById('updatePostForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the form from refreshing the page

    // Get the input values
    const postId = document.getElementById('postId').value;
    const title = document.getElementById('title').value;
    const body = document.getElementById('body').value;

    // Create the updated post data
    const updatedPostData = {
        title: title,
        body: body,
        userId: 1 // Assuming a static userId for this mock API
    };

    // Create a new XMLHttpRequest object
    const xhr = new XMLHttpRequest();

    // Open the PUT request
    xhr.open('PUT', `https://jsonplaceholder.typicode.com/posts/${postId}`, true);
    xhr.setRequestHeader('Content-Type', 'application/json'); // Set the header to JSON

    // Define what happens on successful request
    xhr.onload = function() {
        if (xhr.status === 200) {
            // Parse the response
            const response = JSON.parse(xhr.responseText);

            // Display the updated post data on the webpage
            const updatedPostDiv = document.getElementById('updatedPost');
            updatedPostDiv.innerHTML = `
                <p><strong>Post Updated Successfully!</strong></p>
                <p><strong>Post ID:</strong> ${response.id}</p>
                <p><strong>Title:</strong> ${response.title}</p>
                <p><strong>Body:</strong> ${response.body}</p>
            `;
        } else {
            // Handle errors (if any)
            const updatedPostDiv = document.getElementById('updatedPost');
            updatedPostDiv.innerHTML = `<p style="color: red;">Error: ${xhr.statusText}</p>`;
        }
    };

    // Define what happens if the request fails
    xhr.onerror = function() {
        const updatedPostDiv = document.getElementById('updatedPost');
        updatedPostDiv.innerHTML = `<p style="color: red;">Error: Could not send request.</p>`;
    };

    // Send the PUT request with the updated post data
    xhr.send(JSON.stringify(updatedPostData));
});